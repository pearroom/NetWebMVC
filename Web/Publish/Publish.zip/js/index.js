
function load(url){
	$("#_content_").load(url);
}